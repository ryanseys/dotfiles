#parse("Ruby File Header.rb")

require "test_helper"

class ${NAME} < ActiveSupport::TestCase
  def setup
    # Do nothing
  end

  test "#example does something" do
    skip "not implemented"
  end
end