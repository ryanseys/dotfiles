#parse("Ruby File Header.rb")

#set( $root = $DIR_PATH )
#set( $directories = $root.split("/") )

#foreach ($directory in $directories)
#if ($foreach.hasNext)
module $directory
#else
class $directory
#end
#end
#foreach ($_ in $directories)
end
#end
